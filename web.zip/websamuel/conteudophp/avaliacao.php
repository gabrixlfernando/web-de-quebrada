
    <!-----------avaloação dos clientes---------->
    <section aria-labelledby="seção avaliação clientes" data-aos="fade-up">
      <div class="site">
        <div class="clientes-cont">
          <div class="clientes-titulo">
            <h2>Nossos <span>Clientes</span></h2>
            <p>
              Veja alguns depoimentos de clientes satisfeitos com o serviço
              prestado.
            </p>

          </div>
          <div class="clientes clientesCarro">
            <div class="client">
              <img src="img/cliente.1.svg" class="cliente-perfil" alt="foto de perfil de um cliente do site" />
              <h3>Nome</h3>
              <p>
                A empresa de desenvolvimento de sites foi incrível em criar um
                site responsivo e de alta qualidade para a minha empresa.
              </p>
            </div>
            <div class="client">
              <img src="img/cliente.2.svg" class="cliente-perfil" alt="foto de perfil de um cliente do site" />
              <h3>Nome</h3>
              <p>
                A empresa de desenvolvimento de sites foi incrível em criar um
                site responsivo e de alta qualidade para a minha empresa.
              </p>
            </div>
            <div class="client">
              <img src="img/cliente.3.svg" class="cliente-perfil" alt="foto de perfil de um cliente do site" />
              <h3>Nome</h3>
              <p>
                A empresa de desenvolvimento de sites foi incrível em criar um
                site responsivo e de alta qualidade para a minha empresa.
              </p>
            </div>
            <div class="client">
              <img src="img/cliente.4.svg" class="cliente-perfil" alt="foto de perfil de um cliente do site" />
              <h3>Nome</h3>
              <p>
                A empresa de desenvolvimento de sites foi incrível em criar um
                site responsivo e de alta qualidade para a minha empresa.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!----avaloação dos clientes fim---------->


    <!-----------sobre começo---------->
    <section aria-labelledby="seção de sobre" id="sobre" class="site">
      <div class="sobre site">
        <img data-aos="fade-right" src="img/imgsobre.png" alt="um grupo de pessoas sobrepondo as suas maõs sobre as outras" />

        <div data-aos="fade-left" class="sobre-info">
          <h2>Um pouco <span>Sobre nós</span></h2>
          <p>
            A <b>Web de Quebrada</b> é uma agência de desenvolvimento web que
            cria sites institucionais e e-commerce. Desde a nossa fundação,
            nos dedicamos a fornecer soluções de alta qualidade para empresas
            de diversos segmentos, sempre com um olhar atento às tendências e
            necessidades do mercado.
          </p>
          <a role="link" href="#" class="sobre-btn">Ler mais</a>
        </div>
      </div>
    </section>
    <!----------- sobre fim---------->
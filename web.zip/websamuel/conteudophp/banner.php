<section class="banner">
  <h1>.</h1>


  <div aria-labelledby="carrosel de palavras" class="slogan-cont">

    <div class="slogan-words">
      <p>Criação de sites</p>
      <div class="words">
        <span>Modernos.</span>
        <span>Institucionais.</span>
        <span>Responsivos.</span>
        <span>Otimizados.</span>
        <span>Modernos.</span>
      </div>
      <div class="slogan-btn-cont">
        <a role="link" href="formulario.php" target="_blank" class="slogan-btn">Contratar</a>
      </div>
    </div>

  </div>
</section>
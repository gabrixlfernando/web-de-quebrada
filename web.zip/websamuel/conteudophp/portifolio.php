

    <!-----------portifolio começo---------->
    <section aria-labelledby="seção do portifolio" id="portfolio" data-aos="fade-up">
      <div class="portfolio-titulo">
        <h2>Conheça o nosso <span>Portfólio</span></h2>
        <p>Veja alguns de nossos projetos publicados</p>
      </div>

      <div class="portfolio-cont">
        <div class="portfolio">
          <div>
            <img src="img/seta.svg" alt="seta laranja apontando para baixo" />
          </div>
          <div>
            <img src="img/seta.svg" alt="seta laranja apontando para baixo" />
          </div>
          <div>
            <img src="img/seta.svg" alt="seta laranja apontando para baixo" />
          </div>
          <div>
            <img src="img/seta.svg" alt="seta laranja apontando para baixo" />
          </div>
        </div>
        <div>
          <a role="link" href="#" class="btnConfira">Confira</a>
        </div>
      </div>
    </section>
    <!----------- portifolio fim---------->
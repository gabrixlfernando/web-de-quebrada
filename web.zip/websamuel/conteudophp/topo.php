 <!-----------Topo---------->
 <div class="topo-corpo" aria-describedby="topo do site">
   <header id="top">
     <a title="Botao" href="formulario.php" class="topo-btn">Contratar</a>
     <h1 data-menssage="logo da empresa escrito web de quebrada!" id="LOG">Logo</h1>

     <div aria-describedby="menu mobile" id="menu" class="menu-mobile">
       <!---dark btn-->
       <strong>Modo escuro</strong>
       <div class="const">
         <div class="but2">

         </div>
       </div>
       <!--darkfim-->
       <ul>
         <li class="menu-item"><a role="link" href="index.php" class="menu-link">Início</a></li>
         <li class="menu-item">
           <a role="link" href="#servico" class="menu-link">Serviços</a>
         </li>
         <li class="menu-item">
           <a role="link" href="sobrelink.php" class="menu-link">Sobre</a>
         </li>
         <li class="menu-item">
           <a role="link" href="portfoliolink.php" class="menu-link">Portfólio</a>
         </li>
       </ul>

       <div class="topo-rede-social">
         <a role="link" href="#">LinkedIn</a>
         <a role="link" href="#">WhatsApp</a>
         <a role="link" href="#">Instagram</a>
       </div>

     </div>

     <div class="mobile-menu-icon">
       <button onclick="menuShow(); toggleMenu()">
         <img class="icon-menu" src="img/menu/btn-abrirmenu.svg" alt="menu hamburguer" />
       </button>
     </div>
     <nav class="nav-menu">
       <ul>
         <li class="menu-item">
           <a role="link" href="index.php" class="ativo menu-link">Início</a>
         </li>
         <li class="menu-item">
           <a role="link" href="#servico" class="menu-link">Serviços</a>
         </li>
         <li class="menu-item">
           <a role="link" href="sobrelink.php" class="menu-link">Sobre</a>
         </li>
         <li class="menu-item">
           <a role="link" href="portfoliolink.php" class="menu-link">Portfólio</a>
         </li>
       </ul>
       <div class="topo-rede-social">
         <a role="link" href="#">LinkedIn</a>
         <a role="link" href="#">WhatsApp</a>
         <a role="link" href="#">Instagram</a>
       </div>
       <!---dark btn-->
       <div class="container">
         <div class="btn1">

         </div>
       </div>
       <!--darkfim-->

     </nav>

   </header>

 </div>

 <main>
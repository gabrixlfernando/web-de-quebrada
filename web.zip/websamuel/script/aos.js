// inicializador do AOS
AOS.init();
